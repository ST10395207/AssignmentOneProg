/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StudentsTest;

import assignmentoneprog.Students;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jaido
 */
public class StudentsTest {

    @Test
    public void testSaveStudent() {
        ArrayList<Students> students = new ArrayList<>();
        int studentID = 1;
        String studentName = "John";
        int studentAge = 20;
        String studentEmail = "john@example.com";
        String studentCourse = "Computer Science";
        
        Students.saveStudent(students, studentID, studentName, studentAge, studentEmail, studentCourse);
        
        assertEquals(1, students.size());
        Students savedStudent = students.get(0);
        assertEquals(studentID, savedStudent.getID());
        assertEquals(studentName, savedStudent.getName());
        assertEquals(studentAge, savedStudent.getAge());
        assertEquals(studentEmail, savedStudent.getEmail());
        assertEquals(studentCourse, savedStudent.getCourse());
    }

    @Test
    public void testSearchStudent() {
        Students student = new Students("John", "john@example.com", "Computer Science", 1, 20);
        ArrayList<Students> students = new ArrayList<>();
        students.add(student);
        
        Students foundStudent = Students.searchStudent(students, 1);
        
        assertNotNull(foundStudent);
        assertEquals(student.getID(), foundStudent.getID());
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        ArrayList<Students> students = new ArrayList<>();
        Students foundStudent = Students.searchStudent(students, 99);
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        Students student = new Students("John", "john@example.com", "Computer Science", 1, 20);
        ArrayList<Students> students = new ArrayList<>();
        students.add(student);
        
        boolean deleted = Students.deleteStudent(students, 1);
        
        assertTrue(deleted);
        assertEquals(0, students.size());
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        ArrayList<Students> students = new ArrayList<>();
        boolean deleted = Students.deleteStudent(students, 99);
        assertFalse(deleted);
    }

    @Test
    public void testStudentAge_StudentAgeValid() {
        assertTrue(Students.isStudentAgeValid(18));
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        assertFalse(Students.isStudentAgeValid(15));
    }

    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        assertFalse(Students.isStudentAgeValid("abc")); 
    }
}

    
    
    
    

    

