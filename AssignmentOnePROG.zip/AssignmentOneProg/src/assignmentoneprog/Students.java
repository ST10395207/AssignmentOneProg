/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignmentoneprog;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author jaido
 */
public class Students { 
    
    public static String name;
    public static String email;
    public static String course;
    public static int ID;
    public static int age;

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    public int getID() {
        return ID;
    }

    public int getAge() {
        return age;
    }

    public ArrayList<Students> getStudents() {
        return students;
    }


//constructor
    public Students(String name, String email, String course, int ID, int age, ArrayList<Students> students) {
        this.name = name;
        this.email = email;
        this.course = course;
        this.ID = ID;
        this.age = age;
        this.students = students;
    }
    

    final static Scanner kb = new Scanner(System.in);  
       
    //array list for each varibale
    private final ArrayList<Students> students;
       
        public static void saveStudent(ArrayList<Students> students, Scanner kb){
            System.out.println("Enter the student id: ");
        ID = Integer.parseInt(kb.next());
            System.out.println("Enter the student name: ");
        name = kb.next();
        
            System.out.println("Enter the student age:" );
        int Age =kb.nextInt();
    //verify age from the start
        if (Age < 16)  {
            System.out.println("You have entered a incorrect student age!!!\nPlease re-enter the student age");
            return;
        } 
            System.out.println("Enter the student email: ");
        email = kb.next();
        
            System.out.println("Enter the student course: ");
        course = kb.next(); 
    //names to store
    
            System.out.println("Student added successfully!");
    }//student method end 
      
    public static void searchStudent(ArrayList<Students> students, Scanner kb) {
            System.out.println("Enter the student id to search: ");
        int ID = kb.nextInt();
        boolean found = false;
        for(Students student : students){
            if(student.getID()== ID){
                found = true;
                    System.out.println("STUDENT ID: " + student.getID());
                    System.out.println("STUDENT NAME: " + student.getName());
                    System.out.println("STUDENT AGE: " + student.getAge());
                    System.out.println("STUDENT EMAIL: " + student.getEmail());
                    System.out.println("STUDENT COURSE: " + student.getCourse());
                break; 
            } 
        }//for loop end
        if(!found) {
            System.out.println("Student with Id: " + ID + " was not found!");
        }
    }//student search end
       
    public static void deleteStudent(ArrayList<Students> students, Scanner kb) {
          System.out.println("Please enter student id to delete: ");
          int deleteStudent = kb.nextInt();
          int indexToRemove = -1;
          for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getID() ==ID) {
                indexToRemove = i;
                break;
            }
        }
    if (indexToRemove != -1) {
            students.remove(indexToRemove);
            System.out.println("Student with Student Id: " + ID + " WAS deleted!");
        } else {
            System.out.println("Student with ID: " + ID + " does not exist.");
        }
    }
    public static void studentReport(){
        System.out.println("------------------------------");
        System.out.println("STUDENT ID: " + ID);
        System.out.println("STUDENT NAME: " + name);
        System.out.println("STUDENT AGE: " + age);
        System.out.println("STUDENT EMAIL: " + email);
        System.out.println("STUDENT COURSE: " + course);
        System.out.println("-------------------------------");
    }
    
    
    public static void saveStudent(ArrayList<Students> students, int studentID, String studentName, int studentAge, String studentEmail, String studentCourse) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static Students searchStudent(ArrayList<Students> students, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static boolean deleteStudent(ArrayList<Students> students, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static boolean isStudentAgeValid(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static boolean isStudentAgeValid(String abc) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Students(String john, String johnexamplecom, String computer_Science, int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
} //main end 


    

