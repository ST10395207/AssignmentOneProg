/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignmentoneprog;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author jaido
 */
public class AssignmentOneProg {

    /**
     * @param args the command line arguments
     */
    
    public static String userChoice;
    public static String name;
    public static String email;
    public static String course;
    public static int ID;
    public static int age;
       
    final static Scanner kb = new Scanner(System.in); 
    final static ArrayList<Students> students = new ArrayList<>();

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*********************************");
        System.out.println("Enter (1) to launch menu or any other key to exist");
        userChoice = kb.next();
        
        //verifying user input
        if (userChoice.equals("1")) {
            Menu();
            
        } else {
            System.exit(0);
        }
    } 
        public static void Menu(){
        //indroduce the switch cSE 
        int choice;
        boolean quit = false;
        while (!quit){
            System.out.println("Please select one of the following menu items: \n"
                   + "\n (1) Capture a new student."
                   + "\n (2) Search for a student."
                   + "\n (3) Delete a student."
                   + "\n (4) Print student report."
                   + "\n (5) Exit application.");
            choice = kb.nextInt();
            
            switch(choice){
                case 1: Students.saveStudent(students, kb);
                    break;
                case 2: Students.searchStudent(students, kb);
                    break;
                case 3: Students.deleteStudent(students, kb);
                    break;
                case 4: Students.studentReport();
                    break;
                case 5: 
                    break;
                default: System.out.println("Invalid entry, please try again");    
                    break;
            }
        }
    } //end of menu()
        
} //end of main 

    

    

