
import assignmentoneprogq2.AssignmentOneProgQ2;
import assignmentoneprogq2.Employee;
import assignmentoneprogq2.Manager;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.*;
import org.junit.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jaido
 */
public class EmployeeManagementSystemTest {
    
    private Employee[] employees;
    private int employeeCount;

    @Before
    public void setUp() {
        // Initialize employees array
        employees = new Employee[50];
        employeeCount = 0;
    }

    @Test
    public void testAddEmployee() {
        // Test adding a regular employee
        Employee employee = new Employee("John Doe", 1, 50000.0);
        employees[employeeCount++] = employee;
        assertEquals(1, employeeCount);
        assertEquals("John Doe", employees[0].getName());

        // Test adding a manager
        Manager manager = new Manager("Alice Smith", 2, 60000.0, "HR");
        employees[employeeCount++] = manager;
        assertEquals(2, employeeCount);
        assertEquals("Alice Smith", employees[1].getName());
        assertEquals("HR", ((Manager) employees[1]).getDepartment());
    }

    @Test
    public void testListEmployees() {
        // Test listing employees
        Employee employee1 = new Employee("John Doe", 1, 50000.0);
        employees[employeeCount++] = employee1;

        Manager manager = new Manager("Alice Smith", 2, 60000.0, "HR");
        employees[employeeCount++] = manager;

        AssignmentOneProgQ2.listEmployees(employees, employeeCount);

        // Capture the output and check if it contains the employee information
        String output = getConsoleOutput();
        assertTrue(output.contains("Employee Type: Employee"));
        assertTrue(output.contains("Name: John Doe"));
        assertTrue(output.contains("Employee ID: 1"));
        assertTrue(output.contains("Salary: $50000.0"));
        assertTrue(output.contains("Employee Type: Manager"));
        assertTrue(output.contains("Name: Alice Smith"));
        assertTrue(output.contains("Employee ID: 2"));
        assertTrue(output.contains("Salary: $60000.0"));
        assertTrue(output.contains("Department: HR"));
    }

    // Helper method to capture console output
    private String getConsoleOutput() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        AssignmentOneProgQ2.listEmployees(employees, employeeCount);
        return outContent.toString();
    }
}

    

