/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignmentoneprogq2;

import java.util.Scanner;

/**
 *
 * @author jaido
 */
public class AssignmentOneProgQ2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scanner = new Scanner(System.in);

        int maxEmployees = 50;
        Employee[] employees = new Employee[maxEmployees];
        int employeeCount = 0;

        boolean quit = false;
        while (!quit) {
            System.out.println("Employee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. List Employees");
            System.out.println("3. Quit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    if (employeeCount < maxEmployees) {
                        System.out.print("Enter employee name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter employee ID: ");
                        int employeeId = scanner.nextInt();
                        System.out.print("Enter employee salary: ");
                        double salary = scanner.nextDouble();
                        scanner.nextLine(); 

                        System.out.println("Is this employee a manager? (y/n): ");
                        String isManager = scanner.nextLine().trim().toLowerCase();

                        if (isManager.equals("y")) {
                            System.out.print("Enter manager's department: ");
                            String department = scanner.nextLine();
                            employees[employeeCount] = new Manager(name, employeeId, salary, department);
                        } else {
                            employees[employeeCount] = new Employee(name, employeeId, salary);
                        }

                        employeeCount++;
                        System.out.println("Employee added successfully!");
                    } else {
                        System.out.println("Employee database is full.");
                    }
                    break;

                case 2:
                    System.out.println("List of Employees:");
                    for (int i = 0; i < employeeCount; i++) {
                        Employee emp = employees[i];
                        String employeeType = (emp instanceof Manager) ? "Manager" : "Employee";
                        System.out.println("Employee Type: " + employeeType);
                        System.out.println("Name: " + emp.getName());
                        System.out.println("Employee ID: " + emp.getEmployeeId());
                        System.out.println("Salary: $" + emp.getSalary());
                        if (emp instanceof Manager) {
                            Manager manager = (Manager) emp;
                            System.out.println("Department: " + manager.getDepartment());
                        }
                        System.out.println("-------------------------");
                    }
                    break;

                case 3:
                    quit = true;
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    public static void listEmployees(Employee[] employees, int employeeCount) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
    

